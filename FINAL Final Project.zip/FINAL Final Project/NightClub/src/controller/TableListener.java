package controller;



import java.util.EventListener;

import controller.tableEvents.LoginButtonEvent;

import controller.tableEvents.MyEventsMenuEvent;
import controller.tableEvents.PastEvent;
import controller.tableEvents.UpcomingEvent;
import controller.tableEvents.ZipWithin15MenuEvent;
import controller.tableEvents.ZipWithin50MenuEvent;

public class TableListener implements EventListener {

	public void allEventsLogin(){
		
	}
	
	public void eventRecommendationLogin(){
		
	}
	
	public void allEventsMenuClicked(){
		
	}
	
	public void myEventsMenuClicked(MyEventsMenuEvent ev){
		
	}
	
	public void zipWithin15Clicked(ZipWithin15MenuEvent ev){
		
	}
	
	public void zipWithin50Clicked(ZipWithin50MenuEvent ev){
		
	}
	
	public void upcomingEventsClicked(UpcomingEvent ev){
		
	}
	
	public void pastEventsClicked(PastEvent ev){
		
	}
	
    public void searchButtonClicked(SearchButtonEvent ev){
		
	}
    
    
    //---------------------Event Creation-------------------------
    
	public void createButtonClicked(CreateButtonEvent ev){
		
	}
	
	public void deleteButtonClicked(DeleteButtonEvent ev){
		
	}
	
	public void updateButtonClicked(UpdateButtonEvent ev){
		
	}
	
	//---------------------Employee Creation---------------------------
	public void addEmployeeButtonClicked(EmployeeEvent ev){
		
	}
	
	public void viewEmployeeHlClicked(){
		
	}
	
	public void rowSelected(EmployeeEvent ev){
		
	}
	
}
