package controller;

import java.util.EventListener;

public class Pane4EventListener implements EventListener {

	public void rowSelected(Pane4EventEvent ev) {
		
	}
	
	public void ticketsClicked(TicketButtonEvent ev){
		
	}

	public void checkoutClicked(CheckoutButtonEvent ev) {
		
		
	}
	public void placeOrderClicked(PlaceOrderEvent ev) {
		
		
	}
	
	public void eventRowSelected(ClickEventEvent ev) {
		
		
	}
	
	public void myOrdersClicked(MyOrderEvent ev) {
		
		
	}
	
	public void returnEventClicked(ReturnTicketEvent ev) {
		
		
	}
}
