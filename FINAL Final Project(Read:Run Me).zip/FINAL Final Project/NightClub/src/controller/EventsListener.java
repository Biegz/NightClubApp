package controller;

import java.util.EventListener;

public class EventsListener implements EventListener{

	public void createButtonClicked(CreateButtonEvent ev){
		
	}
	
	public void deleteButtonClicked(DeleteButtonEvent ev){
		
	}
	
	public void updateButtonClicked(UpdateButtonEvent ev){
		
	}
	
	
	
}
