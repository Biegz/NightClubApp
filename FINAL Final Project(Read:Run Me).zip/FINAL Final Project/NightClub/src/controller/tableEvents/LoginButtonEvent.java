package controller.tableEvents;

public class LoginButtonEvent {

}
